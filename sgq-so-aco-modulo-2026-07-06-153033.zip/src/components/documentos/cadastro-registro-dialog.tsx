"use client";

import { useRouter } from "next/navigation";
import { useMemo, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  buildExternoRegistroMeta,
  buildPermissoesFromExternoRegistro,
  defaultExternoRegistroValues,
  DocumentoExternoRegistroCampos,
  type ExternoRegistroFormValues,
} from "@/components/documentos/documento-externo-registro-campos";
import { afterUiTransition } from "@/lib/motion";
import { useDocumentsStore } from "@/lib/store/documents-store";
import { useConfigStore } from "@/lib/store/config-store";

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const REGISTRO_SIGLA = "RE";

export function CadastroRegistroDialog({ open, onOpenChange }: Props) {
  const router = useRouter();
  const createDocument = useDocumentsStore((s) => s.createDocument);
  const documents = useDocumentsStore((s) => s.documents);
  const documentTypes = useConfigStore((s) => s.documentTypes);
  const departments = useConfigStore((s) => s.departments);
  const users = useConfigStore((s) => s.users);
  const currentUserId = useConfigStore((s) => s.currentUserId);

  const [values, setValues] = useState<ExternoRegistroFormValues>(() =>
    defaultExternoRegistroValues(currentUserId)
  );

  const registroTipo = useMemo(() => {
    const found = documentTypes.find((t) => t.sigla === REGISTRO_SIGLA);
    return (
      found ?? {
        id: "tipo-re",
        nome: "Registro",
        sigla: REGISTRO_SIGLA,
      }
    );
  }, [documentTypes]);

  function resetForm() {
    setValues(defaultExternoRegistroValues(currentUserId));
  }

  function handleClose() {
    onOpenChange(false);
    afterUiTransition(resetForm);
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (
      !values.titulo ||
      !values.processoId ||
      !values.localizacao ||
      !values.responsavelId
    ) {
      return;
    }
    if (!values.distEletronica && !values.distFisica) return;

    const id = createDocument({
      tipoSigla: registroTipo.sigla,
      titulo: values.titulo,
      tipoId: registroTipo.id,
      setorId: values.processoId,
      elaboradorId: values.responsavelId,
      origem: "registro",
      localizacao: values.localizacao,
      permissoes: buildPermissoesFromExternoRegistro(values),
      externoRegistro: buildExternoRegistroMeta(values),
      arquivoNome: values.anexoNome,
      arquivoDataUrl: values.anexoDataUrl,
    });

    onOpenChange(false);
    afterUiTransition(() => {
      resetForm();
      router.push(`/documentos/${id}`);
    });
  }

  return (
    <Dialog open={open} onOpenChange={(v) => (v ? onOpenChange(v) : handleClose())}>
      <DialogContent
        showCloseButton={false}
        className="max-h-[min(92vh,100dvh)] w-full max-w-5xl flex-col gap-0 overflow-hidden p-0 sm:max-w-5xl"
      >
        <div className="modal-header-bar flex shrink-0 items-center justify-between px-5 py-3.5">
          <h2 className="text-base font-semibold text-white">
            Cadastro de registro
          </h2>
          <button
            type="button"
            onClick={handleClose}
            className="rounded p-1.5 hover:bg-white/20"
            aria-label="Fechar"
          >
            <X className="size-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex min-h-0 flex-1 flex-col">
          <div className="min-h-0 flex-1 overflow-y-auto overscroll-y-contain p-6">
            <DocumentoExternoRegistroCampos
              values={values}
              onChange={setValues}
              users={users}
              departments={departments}
              documents={documents}
              showValidade={false}
            />
          </div>

          <div className="sgq-form-footer">
            <Button type="submit" size="lg" className="min-w-28">
              Gravar
            </Button>
            <Button type="button" variant="secondary" size="lg" disabled>
              Inativar
            </Button>
            <Button
              type="button"
              variant="outline"
              size="lg"
              onClick={handleClose}
            >
              Fechar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
