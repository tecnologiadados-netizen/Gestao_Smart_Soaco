import { AppHeader } from "@/components/layout/app-header";
import { StoreHydration } from "@/components/providers/store-hydration";
export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <StoreHydration>
      <div className="flex min-h-screen flex-col bg-background">
        <AppHeader />
        <main className="w-full flex-1 px-6 py-5 lg:px-8">
          {children}
        </main>
      </div>    </StoreHydration>
  );
}
